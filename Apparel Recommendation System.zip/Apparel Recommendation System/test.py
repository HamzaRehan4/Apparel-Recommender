import pickle  # Importing the pickle module for object serialization
import tensorflow  # Importing the tensorflow library for deep learning
import numpy as np  # Importing the numpy library for scientific computing
from numpy.linalg import norm  # Importing the norm function from numpy.linalg for calculating vector norms
from tensorflow.keras.preprocessing import image  # Importing the image module from tensorflow.keras.preprocessing
# for working with images
from tensorflow.keras.layers import GlobalMaxPooling2D  # Importing the GlobalMaxPooling2D layer for deep learning
# models
from tensorflow.keras.applications.resnet50 import ResNet50, preprocess_input  # Importing the ResNet50 model and
# preprocess_input function for image classification
from sklearn.neighbors import NearestNeighbors  # Importing the NearestNeighbors class for nearest neighbor search
import cv2  # Importing the OpenCV library for computer vision tasks


feature_list = np.array(pickle.load(open('embeddings.pkl', 'rb')))  # Load the feature list from a pickle file and
# convert it to a NumPy array
filenames = pickle.load(open('filenames.pkl', 'rb'))  # Load the filenames from a pickle file

model = ResNet50(weights='imagenet', include_top=False, input_shape=(224, 224, 3))  # Load the ResNet50 model with
# pre-trained weights and specify the input shape
model.trainable = False  # Freeze the model's weights to prevent training

model = tensorflow.keras.Sequential([  # Create a sequential model
    model,  # Add the ResNet50 model as a layer
    GlobalMaxPooling2D()  # Add a GlobalMaxPooling2D layer for feature aggregation
])


img = image.load_img('sample/jeans1.jpg', target_size=(224, 224))  # Load the image and resize it to (224, 224)
img_array = image.img_to_array(img)  # Convert the image to a NumPy array
expanded_img_array = np.expand_dims(img_array, axis=0)  # Expand dimensions to create a batch of size 1
preprocessed_img = preprocess_input(expanded_img_array)  # Preprocess the image for the model input
result = model.predict(preprocessed_img).flatten()  # Use the model to predict the features and flatten the result
normalized_result = result / norm(result)  # Normalize the result by dividing it by its norm


# jaccard-distance
# hamming
neighbors = NearestNeighbors(n_neighbors=5, algorithm='cosine', metric='correlation-based')
# finding 5 nearest neighbours to the test image being passed using the Euclidean distance
neighbors.fit(feature_list)

distances, indices = neighbors.kneighbors([normalized_result])

print(indices)

for file in indices[0][1:5]:  # Iterate over the recommended file indices (excluding the first index)
    temp_img = cv2.imread(filenames[file])  # Read the image corresponding to the file index using OpenCV
    cv2.imshow('output', cv2.resize(temp_img, (512, 512)))  # Display the resized image with OpenCV
    cv2.waitKey(0)  # Wait for a key press to continue to the next image

