import tensorflow
from tensorflow.keras.preprocessing import image
from tensorflow.keras.layers import GlobalMaxPooling2D
from tensorflow.keras.applications.resnet50 import ResNet50, preprocess_input
import numpy as np
from numpy.linalg import norm
import os
from tqdm import tqdm
import pickle

# the input shape of our images provided to the imagenet model will be (224, 224, 3)
model = ResNet50(weights='imagenet', include_top=False, input_shape=(224, 224, 3))

# using pre-trained model and using already used weights
# already trained on imagenet dataset
model.trainable = False

model = tensorflow.keras.Sequential([
    model,
    # extracting the most prominent features of the images
    GlobalMaxPooling2D()
])


# print(model.summary())

# this function will extract features from all the images one by one
def extract_features(img_path, model):
    # Load and preprocess the image
    img = image.load_img(img_path, target_size=(224, 224))  # Load the image and resize it to (224, 224)

    img_array = image.img_to_array(img)  # Convert the image to a NumPy array
    expanded_img_array = np.expand_dims(img_array, axis=0)

    # The images are converted from RGB to BGR, then each color channel is zero-centered with respect to the ImageNet
    # dataset.
    preprocessed_img = preprocess_input(expanded_img_array)
    # flattening the array in 1D
    result = model.predict(preprocessed_img).flatten()
    normalized_result = result / norm(result)

    return normalized_result


# list named filenames for storing each image
filenames = []

# this loop will run according to the size of our dataset present in the images folder
for file in os.listdir('images'):
    filenames.append(os.path.join('images', file))

# a 2-D list that will store the feature extracted of every image
feature_list = []

for file in tqdm(filenames):
    feature_list.append(extract_features(file, model))

# features extracted from all the images are stored in this file
# this will work as a knowledge base
pickle.dump(feature_list, open('embeddings.pkl', 'wb'))
pickle.dump(filenames, open('filenames.pkl', 'wb'))
