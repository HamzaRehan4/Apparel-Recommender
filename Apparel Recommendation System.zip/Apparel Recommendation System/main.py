import streamlit as st  # Importing Streamlit library for building interactive web applications
import os  # Importing the os module for interacting with the operating system
from PIL import Image  # Importing the Image module from PIL for image processing
import numpy as np  # Importing the numpy library for scientific computing
import pickle  # Importing the pickle module for object serialization
import tensorflow  # Importing the tensorflow library for deep learning
from tensorflow.keras.preprocessing import image  # Importing the image module from tensorflow.keras.preprocessing
# for working with images
from tensorflow.keras.layers import GlobalMaxPooling2D  # Importing the GlobalMaxPooling2D layer for deep learning
# models
from tensorflow.keras.applications.resnet50 import ResNet50, preprocess_input  # Importing the ResNet50 model and
# preprocess_input function for image classification
from sklearn.neighbors import NearestNeighbors  # Importing the NearestNeighbors class for nearest neighbor search
from numpy.linalg import norm  # Importing the norm function from numpy.linalg for calculating vector norms

# Loading the feature embeddings and filenames of the images
feature_list = np.array(pickle.load(open('embeddings.pkl', 'rb')))
filenames = pickle.load(open('filenames.pkl', 'rb'))

# Loading a pre-trained ResNet50 model with weights trained on ImageNet and make it non-trainable
model = ResNet50(weights='imagenet', include_top=False, input_shape=(224, 224, 3))
model.trainable = False

model = tensorflow.keras.Sequential([
    model,
    GlobalMaxPooling2D()
])

st.title('Apparel Recommender System')
st.write('Below is an audio illustration of how my project works:')
st.audio('working.mp3')


# Function to save the user uploaded file to directory
def save_uploaded_file(uploads):
    try:
        with open(os.path.join('uploads', uploaded_file.name), 'wb') as f:
            f.write(uploaded_file.getbuffer())
        return 1
    except:
        return 0


# function to extract features from an image using the ResNet50 model
def feature_extraction(img_path, model):
    # Load and preprocess the image
    img = image.load_img(img_path, target_size=(224, 224))  # Load the image and resize it to (224, 224)
    img_array = image.img_to_array(img)  # Convert the image to a NumPy array
    expanded_img_array = np.expand_dims(img_array, axis=0)  # Expand dimensions to create a batch of size 1
    preprocessed_img = preprocess_input(expanded_img_array)  # Preprocess the image for the model input

    # Extract features using the provided model
    result = model.predict(preprocessed_img).flatten()  # Use the model to predict the features and flatten the result

    # Normalize the feature vector
    normalized_result = result / norm(result)  # Normalize the result by dividing it by its norm

    return normalized_result  # Return the normalized feature vector


def recommend(features, feature_list):
    neighbors = NearestNeighbors(n_neighbors=6, algorithm='brute', metric='euclidean')
    neighbors.fit(feature_list)

    distances, indices = neighbors.kneighbors([features])

    return indices


# steps
# file upload -> save
# Prompt the user to upload an image file
uploaded_file = st.file_uploader("Please upload an image")
# Check if a file was uploaded
if uploaded_file is not None:
    if save_uploaded_file(uploaded_file):
        # display the file
        display_image = Image.open(uploaded_file)
        st.image(display_image)
        # Extract features from the uploaded image
        features = feature_extraction(os.path.join("uploads", uploaded_file.name), model)
        # st.text(features)
        # recommendation
        # Perform recommendation based on extracted features
        indices = recommend(features, feature_list)

        # Display the recommended images in columns
        # Show columns
        col1, col2, col3, col4, col5 = st.columns(5)

        with col1:
            st.image(filenames[indices[0][0]])
        with col2:
            st.image(filenames[indices[0][1]])
        with col3:
            st.image(filenames[indices[0][2]])
        with col4:
            st.image(filenames[indices[0][3]])
        with col5:
            st.image(filenames[indices[0][4]])
    else:
        st.header("Some error occurred while uploading file please try again")
